from turtle import Turtle
file=('data.txt')

class ScoreBoard(Turtle):
    def __init__(self):
        super().__init__()
        with open('data.txt') as data:
            self.high_score= int(data.read())
        self.score=0
        self.shape("circle")
        self.penup()
        self.hideturtle()
        self.setposition(0,270)
        self.score_update()
       
    def score_update(self):
        self.clear()
        self.write(f"Score:{self.score} High score:{self.high_score}", align="center", font="Arial")
    
    def reset(self):
        if self.score > self.high_score:
            self.high_score = self.score
            with open('data.txt', mode='w') as data:
                data.write(f'{self.high_score}')
        self.score =0
        self.score_update()
    # def game_over(self):
    #     self.goto(0,0)
    #     self.write("GAME OVER", align="center", font="Arial")
    
    def score_counter(self):
        self.score+=1
        self.score_update()
        
