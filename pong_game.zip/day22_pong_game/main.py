from turtle import Screen
from paddle import Paddle
from ball import Ball
from scoreboard import ScoreBoard
import time

screen = Screen()
screen.setup(width=800,height=600)
screen.title("PONG Game")
screen.tracer(0)

paddle=Paddle(350,0)
paddle01=Paddle(-350,0)
ball=Ball()
scoreboard = ScoreBoard()

screen.listen()
screen.onkey(paddle.up,"Up")
screen.onkey(paddle.down,"Down")
screen.onkey(paddle01.up,"f")
screen.onkey(paddle01.down,"v")


game_on = True
while game_on:
    time.sleep(ball.move_speed)
    screen.update()
    ball.move()

# top and buttom wall collision
    if ball.ycor() > 280 or ball.ycor() < -280:
        ball.bounce_y()
# collision with tha paddles
    if ball.distance(paddle) <50 and ball.xcor() >320 or ball.distance(paddle01) < 50 and ball.xcor() < -320:
        ball.bounce_x()
# ball out of board
    if ball.xcor() > 380 :
        ball.out_border()
        scoreboard.l_point()

    if ball.xcor() < -380:
        ball.out_border()
        scoreboard.r_point()

screen.exitonclick()