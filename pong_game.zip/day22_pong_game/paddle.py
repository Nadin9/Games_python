from turtle import Turtle

class Paddle(Turtle):
    def __init__(self,x,y):
        super().__init__()
        self.penup()
        self.shape('square')
        self.color('Green')
        self.shapesize(5 ,1 )
        self.setposition(x,y)
        
    #  Movement using the keyboard paddle1=user
    def up(self):
        x_pos=self.xcor()
        y_pos=self.ycor() +25
        self.goto(x_pos,y_pos)

    def down(self):
        x_pos=self.xcor()
        y_pos=self.ycor() -25
        self.goto(x_pos,y_pos)


