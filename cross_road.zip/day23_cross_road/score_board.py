from turtle import Turtle

class ScoreBoard(Turtle):
    def __init__(self):
        super().__init__()
        self.color('White')
        self.penup()
        self.hideturtle()
        self.level=1
        self.update_scoreboard()

    def update_scoreboard(self):
            self.clear()
            self.goto(-240,220)
            self.write(f'level: {self.level}', align='left', font=("Courier", 20, "normal"))
            
            
    def show_levels(self):
         self.level +=1
         self.update_scoreboard()

    def game_over(self):
        self.goto(0,0)
        self.write("GAME OVER", align="center", font=("Courier", 20, "normal"))
    