from turtle import Turtle

INITIAL_POSITION=(0,-200)
FINISH_LINE_Y=280

class Player(Turtle):
    def __init__(self):
        super().__init__()
        self.shape('turtle')
        self.color('White')
        self.penup()
        self.setposition(INITIAL_POSITION)
        self.setheading(90)

    def up(self):
        x_pos=self.xcor()
        y_pos=self.ycor() +25
        self.goto(x_pos,y_pos)

    def down(self):
        x_pos=self.xcor()
        y_pos=self.ycor() -25
        self.goto(x_pos,y_pos)

    def move_right(self):
        x_pos=self.xcor() +25
        y_pos=self.ycor() 
        self.goto(x_pos,y_pos)

    def move_left(self):
        x_pos=self.xcor() -25
        y_pos=self.ycor() 
        self.goto(x_pos,y_pos)

    def is_at_finish_line(self):
        if self.ycor() > FINISH_LINE_Y:
            return True
        else:
            return False


    def restart(self):
        self.goto(INITIAL_POSITION)