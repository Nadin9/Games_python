 # if tim.ycor() > -50:
    #     print("You passed successfuly")