from turtle import Turtle
import random

COLOR=['yellow', 'red', 'green','blue', 'purple']
INITIAL_STEPS=5
SPEED_INCREMENT = 7

class Car(Turtle):
    def __init__(self):
        super().__init__()
        self.all_cars=[]
        self.create_car()
        self.car_speed =INITIAL_STEPS

    def create_car(self):
        random_choice =random.randint(1,6)
        if random_choice == 1:
            new_car = Turtle()
            new_car.penup()
            car_y=random.choice(range(-150,150))
            new_car.setposition(300,car_y)
            new_car.shape('square')
            new_car.shapesize(stretch_len=2,stretch_wid=1)
            new_car.color(random.choice(COLOR))
            
            self.all_cars.append(new_car) 
        

    def move_cars(self):
        for car in self.all_cars:
            car.backward(self.car_speed)

    def level_up(self):
        self.car_speed += SPEED_INCREMENT  