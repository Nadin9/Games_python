from turtle import Screen
from cars import Car
from player import Player
from score_board import ScoreBoard
import time

screen=Screen()
player = Player()
scoreb = ScoreBoard()
car_manager=Car()

screen.setup(width=600,height=600)
screen.bgcolor('DimGray')
screen.title("Cross The Road")
screen.tracer(0)


screen.listen()
screen.onkey(player.up,"Up")
screen.onkey(player.down,"Down")
screen.onkey(player.move_left,"Left")
screen.onkey(player.move_right,"Right")


game_on = True
while game_on:
    time.sleep(0.1)
    screen.update()

    car_manager.create_car()
    car_manager.move_cars()

# Accident
    for car in car_manager.all_cars:
        if car.distance(player) < 20:
            scoreb.game_over()
            game_on=False
# Reaching the finish line

    if player.is_at_finish_line():
        player.restart()
        car_manager.level_up()
        scoreb.show_levels()

    
screen.exitonclick()