import turtle 
import pandas

screen=turtle.Screen()
screen.title("US States Quiz")
image='blank_states_img.gif'
screen.addshape(image)
turtle.shape(image)
tim = turtle.Turtle()
tim.penup()

data = pandas.read_csv('50_states.csv')
guessed_states=[]
score=20
while score >0:
    guess = screen.textinput(title="guess the state", prompt='Guess another one').title()
    
    if guess == "Exit":
        missing_states=[]
        for stat in data.state.to_list():
            if stat not in guessed_states:
                missing_states.append(stat)
                cord= data[data.state == stat]
                tim.color('Red')
                tim.goto(int(cord.x),int(cord.y))
                tim.write(stat)
        break

    
    if guess in data.state.to_list():
        guessed_states.append(guess)
        cor= data[data.state == guess]
        tim.goto(int(cor.x),int(cor.y))
        tim.write(guess)
        score -=1
        


    