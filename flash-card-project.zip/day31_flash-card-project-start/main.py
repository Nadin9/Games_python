from tkinter import *
import pandas
import random
WRONG=0
RIGHT=0
BACKGROUND_COLOR = "#B1DDC6"
current_card={}
""" -------------------data file------------------------"""

try:
    file=pandas.read_csv('data/word_to_learn.csv')
except FileNotFoundError:
# reading the data file and convert it to a dict
    original_file = pandas.read_csv('data/arbic_words.csv')
    data_dict = original_file.to_dict(orient="records")
else:
    data_dict = file.to_dict(orient='records')
"""------------------------------------------"""


def next_card():
    global current_card, flip_timer
    current_card = random.choice(data_dict)
    canvas.itemconfig(word, text= 'English', fill='black')
    canvas.itemconfig(meaning, text=current_card['English'], fill='black')
    canvas.itemconfig(card_image, image=card_front)
    flip_timer= window.after(3000, flip_card)

def flip_card():
    canvas.itemconfig(word, text= 'Arabic', fill='white')
    canvas.itemconfig(meaning, text=current_card['Arabic'],  fill='white')
    canvas.itemconfig(card_image, image=card_back)
    
def known():
    data_dict.remove(current_card)
    saved_data = pandas.DataFrame(data_dict)
    saved_data.to_csv('data/words_to_learn.csv', index=False)
    next_card()
    

        
""" -----------------GUI ---------------------"""
window=Tk()
window.title("FLASH CARD")
window.config( padx=50, pady=50, bg=BACKGROUND_COLOR)
flip_timer =window.after(3000, flip_card)
# window.after_cancel(flip)
card_back= PhotoImage(file='images/card_back.png')
card_front = PhotoImage(file='images/card_front.png')

canvas = Canvas(width=800,height=526, highlightthickness=0, bg=BACKGROUND_COLOR)
card_image = canvas.create_image(400,270, image=card_front)
word = canvas.create_text(400,130, text=" ",font=('Ariel',40,'italic'))
meaning = canvas.create_text(400,250,text="",font=('Ariel',60,'bold'))
canvas.grid(column=0,row=0, columnspan=2)

# right/wrong buttons
right = PhotoImage(file='images/right.png')
wrong = PhotoImage(file='images/wrong.png')
right_button = Button(image=right, highlightthickness=0 , bg=BACKGROUND_COLOR, borderwidth=0 , command=known)
right_button.grid(column=0, row=1)
wrong_button =Button(image=wrong, highlightthickness=0 , bg=BACKGROUND_COLOR, borderwidth=0, command=next_card)
wrong_button.grid(column=1, row=1)

next_card()
window.mainloop()